/**
 * Volt Platform Frontend API Client
 */

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "/api/v1";

export async function fetchHealth() {
  const res = await fetch("/health");
  return res.json();
}

export async function fetchTables() {
  const res = await fetch(`${API_BASE}/pipelines/tables`);
  return res.json();
}

export async function executeQuery(sql: string) {
  const res = await fetch(`${API_BASE}/pipelines/query`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ sql }),
  });
  return res.json();
}

export async function fetchEntities() {
  const res = await fetch(`${API_BASE}/features/entities`);
  return res.json();
}

export async function fetchFeatureViews() {
  const res = await fetch(`${API_BASE}/features/views`);
  return res.json();
}

export async function queryRAG(query: string) {
  const res = await fetch(`${API_BASE}/llm/rag/query`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query }),
  });
  return res.json();
}
